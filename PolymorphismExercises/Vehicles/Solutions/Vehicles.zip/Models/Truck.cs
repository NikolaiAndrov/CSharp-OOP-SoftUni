﻿namespace Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double AdditionalFuelconsumption = 1.6;
        public Truck(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption, AdditionalFuelconsumption)
        {
            
        }

        public override void Refuel(double liters)
        {
            base.Refuel(liters * 0.95);
        }
    }
}
